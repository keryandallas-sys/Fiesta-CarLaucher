package fr.ibiza.launcher;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.provider.Settings;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * v1.29 : « Apprendre l'ordinateur de bord sans appli » (Réglages > Données CAN du poste).
 *
 * Pour les postes sans appli CAN lisible : le client saisit les valeurs de son tableau de bord, le lanceur les cherche
 * dans ce que le poste publie (voir ValueFind), puis les lit en direct aux emplacements trouvés.
 *
 * Sources relevées :
 *   T  trames du boîtier CAN sur les postes TopWay (TWUtil, lecture seule, déjà ouvert pour les portes)
 *   B  diffusions des applis du poste (tableaux d'octets et champs numériques)
 *   P  propriétés système (celles que CanBridge relève déjà toutes les 5 s)
 *   S  réglages système (tables System / Global / Secure), lus au moment du relevé
 *
 * Ce qui ne change pas : les portes, « Apprendre ma voiture », la lecture de CarCan ou de l'appli CAN apprise. Une
 * donnée déjà fournie par une autre source (CarCan, appli apprise, journal…) n'est jamais remplacée par une valeur
 * apprise ici (voir Hub.mergeLearned). Sans relevé fait par le client, rien n'est lu ni émis.
 *
 * Les relevés sont gardés dans Android/data/fr.ibiza.launcher/files/ordi_releves.txt : le deuxième relevé peut se faire
 * un autre jour, après un redémarrage du poste. Ils sont aussi ajoutés au journal exporté, pour décoder à la main un
 * boîtier que la recherche automatique ne trouve pas.
 */
final class LearnCar {
    private LearnCar() {}

    private static final String FILE = "ordi_releves.txt", PREFS = "ibz_learncar";
    private static final int MAX_SAMPLES = 8;
    /** réglages / propriétés qui contiennent des nombres sans rapport avec la voiture */
    private static final Pattern TEXT_NOISE = Pattern.compile("volume|bright|timeout|alarm|font|ringtone|bluetooth|wifi|wlan|adb|usb|animat|screen|sound|dtmf|haptic|ringer|battery_|density|dpi|lcd|"
            + "version|build|serial|sdk|date|time|uptime|boot|pid|uid|port|baud|mem|heap|dalvik|net\\.|dhcp|dns|gsm|ril|radio\\.|locale|keyboard|input|pointer|touch|rotation|display", Pattern.CASE_INSENSITIVE);

    private static Context app;
    private static final Object LOCK = new Object();
    private static final ValueFind.FrameStore store = new ValueFind.FrameStore();
    private static final Map<String, String> bText = new java.util.concurrent.ConcurrentHashMap<>();
    private static final List<ValueFind.Sample> samples = new ArrayList<>();
    private static List<ValueFind.Rule> rules = new ArrayList<>();
    private static Map<String, ValueFind.Found> lastResult = new LinkedHashMap<>();
    /** règles en service, par message (« T:0501/65/13 ») ou par clé texte ; remplacées d'un bloc, jamais modifiées */
    private static volatile Map<String, ValueFind.Rule[]> liveBytes = Collections.emptyMap();
    private static volatile Map<String, ValueFind.Rule[]> liveText = Collections.emptyMap();
    private static final Map<String, Double> pending = new HashMap<>(), shown = new HashMap<>();
    private static long lastFlush = 0;
    private static Handler bg;

    /* Le journal (Hub) a son propre verrou, et l'export du journal appelle summary() : pour ne jamais croiser les deux
       verrous, rien n'est écrit dans le journal pendant que LOCK est tenu. Les lignes sont notées ici, puis écrites après. */
    private static final List<String> LATER = new ArrayList<>();
    private static void later(String line) { synchronized (LATER) { if (LATER.size() < 60) LATER.add(line); } }
    private static void drain() {
        List<String> l;
        synchronized (LATER) { if (LATER.isEmpty()) return; l = new ArrayList<>(LATER); LATER.clear(); }
        for (String x : l) Hub.log(x);
    }

    static void init(Context c) {
        synchronized (LOCK) {
            if (app != null) return;
            app = c.getApplicationContext();
            try {
                String s = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("rules", "");
                List<ValueFind.Rule> l = new ArrayList<>();
                for (String line : s.split("\n")) { ValueFind.Rule r = ValueFind.Rule.dec(line); if (r != null) l.add(r); }
                loadSamples();
                apply(l, false);
                if (!l.isEmpty()) later("ORDI APPRIS : " + l.size() + " donnée(s) lue(s) en direct (" + fieldList(l) + ")");
            } catch (Throwable e) { later("ORDI APPRIS : règles illisibles : " + e); }
        }
        drain();
    }

    /* =================== sources poussées par les autres classes =================== */
    /** TopWay : chaque message de TWUtil (appelé sur le fil « ibiza-ts10 ») */
    static void feedTw(int what, int arg1, Object obj) {
        if (!(obj instanceof byte[])) return;
        byte[] b = (byte[]) obj;
        if (b.length == 0 || b.length > 64) return;
        String base = "T:" + hex4(what & 0xFFFF) + "/" + arg1;
        store.put(base, b);
        Map<String, ValueFind.Rule[]> lv = liveBytes;
        if (!lv.isEmpty()) live(lv.get(ValueFind.FrameStore.k1(base, b.length)), b);
    }
    /** diffusion d'une appli du poste (jamais celles du téléphone / Bluetooth / CarPlay : filtrées avant l'appel) */
    static void feedBroadcast(String action, Bundle x) {
        if (action == null || x == null) return;
        Map<String, ValueFind.Rule[]> lb = liveBytes, lt = liveText;
        for (String k : x.keySet()) {
            Object v; try { v = x.get(k); } catch (Throwable e) { continue; }
            String base = "B:" + action + "/" + k;
            if (v instanceof byte[]) {
                byte[] b = (byte[]) v;
                if (b.length == 0 || b.length > 64) continue;
                store.put(base, b);
                if (!lb.isEmpty()) live(lb.get(ValueFind.FrameStore.k1(base, b.length)), b);
            } else if (v instanceof Number || v instanceof String) {
                String s = String.valueOf(v);
                if (ValueFind.number(s) == null) continue;
                if (bText.size() < 300 || bText.containsKey(base)) bText.put(base, s);
                if (!lt.isEmpty()) liveText(lt.get(base), s);
            }
        }
    }
    private static String hex4(int v) { String h = Integer.toHexString(v).toUpperCase(Locale.US); return "0000".substring(Math.min(4, h.length())) + h; }

    /* =================== lecture en direct =================== */
    private static void live(ValueFind.Rule[] rs, byte[] b) {
        if (rs == null) return;
        boolean any = false;
        for (ValueFind.Rule r : rs) {
            if (r.b0 >= 0 && (b[0] & 0xFF) != r.b0) continue;
            Double v = ValueFind.clean(r.field, ValueFind.eval(r, b));
            if (v != null) { synchronized (pending) { pending.put(r.field, v); } any = true; }
        }
        if (any) flush();
    }
    private static void liveText(ValueFind.Rule[] rs, String s) {
        if (rs == null) return;
        boolean any = false;
        for (ValueFind.Rule r : rs) {
            Double v = ValueFind.clean(r.field, ValueFind.evalText(r, s));
            if (v != null) { synchronized (pending) { pending.put(r.field, v); } any = true; }
        }
        if (any) flush();
    }
    /** envoie au lanceur au plus toutes les 2 s (le régime change sans arrêt), et seulement ce qui a changé */
    private static void flush() {
        Map<String, Double> out = new HashMap<>();
        synchronized (pending) {
            long now = System.currentTimeMillis();
            if (now - lastFlush < 2000) return;
            lastFlush = now;
            for (Map.Entry<String, Double> e : pending.entrySet()) if (!e.getValue().equals(shown.get(e.getKey()))) { out.put(e.getKey(), e.getValue()); shown.put(e.getKey(), e.getValue()); }
            pending.clear();
        }
        if (!out.isEmpty()) Hub.mergeLearned(out);
    }
    /** propriétés et réglages : relus toutes les 5 s, seulement s'il existe une règle de ce type */
    private static final Runnable tick = new Runnable() { public void run() {
        Map<String, ValueFind.Rule[]> lt = liveText;
        boolean any = false;
        try {
            Map<String, String> props = null;
            for (Map.Entry<String, ValueFind.Rule[]> e : lt.entrySet()) {
                String k = e.getKey(), v = null;
                if (k.startsWith("P:")) { if (props == null) props = CanBridge.propsCopy(); v = props.get(k.substring(2)); any = true; }
                else if (k.startsWith("S:")) { v = setting(k.substring(2)); any = true; }
                if (v != null) liveText(e.getValue(), v);
            }
        } catch (Throwable ignored) {}
        Handler h = bg;
        if (any && h != null) h.postDelayed(this, 5000);
    }};
    private static String setting(String tableKey) {
        try {
            int i = tableKey.indexOf('/'); String t = tableKey.substring(0, i), k = tableKey.substring(i + 1);
            ContentResolver cr = app.getContentResolver();
            return t.equals("system") ? Settings.System.getString(cr, k) : t.equals("global") ? Settings.Global.getString(cr, k) : Settings.Secure.getString(cr, k);
        } catch (Throwable e) { return null; }
    }

    /** met les règles en service (LOCK tenu) */
    private static void apply(List<ValueFind.Rule> l, boolean save) {
        rules = l;
        Map<String, List<ValueFind.Rule>> byB = new HashMap<>(), byT = new HashMap<>();
        boolean polled = false;
        for (ValueFind.Rule r : l) {
            Map<String, List<ValueFind.Rule>> m = r.text ? byT : byB;
            List<ValueFind.Rule> x = m.get(r.key); if (x == null) m.put(r.key, x = new ArrayList<>());
            x.add(r);
            if (r.text && (r.key.startsWith("P:") || r.key.startsWith("S:"))) polled = true;
        }
        liveBytes = freeze(byB); liveText = freeze(byT);
        synchronized (pending) { pending.clear(); shown.clear(); lastFlush = 0; }
        if (polled) {
            if (bg == null) { HandlerThread t = new HandlerThread("ibiza-ordi", android.os.Process.THREAD_PRIORITY_BACKGROUND); t.start(); bg = new Handler(t.getLooper()); }
            bg.removeCallbacks(tick); bg.postDelayed(tick, 1500);
        }
        if (save && app != null) {
            StringBuilder sb = new StringBuilder();
            for (ValueFind.Rule r : l) sb.append(r.enc()).append('\n');
            app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("rules", sb.toString()).apply();
        }
    }
    private static Map<String, ValueFind.Rule[]> freeze(Map<String, List<ValueFind.Rule>> m) {
        Map<String, ValueFind.Rule[]> out = new HashMap<>();
        for (Map.Entry<String, List<ValueFind.Rule>> e : m.entrySet()) out.put(e.getKey(), e.getValue().toArray(new ValueFind.Rule[0]));
        return out;
    }
    private static String fieldList(List<ValueFind.Rule> l) {
        StringBuilder b = new StringBuilder();
        for (ValueFind.Rule r : l) b.append(b.length() > 0 ? ", " : "").append(r.field);
        return b.toString();
    }

    /* =================== relevé demandé par le client =================== */
    /** values : « odo=123456;outside=18.5 » (ce que le client lit sur son tableau de bord). Renvoie le résultat en JSON. */
    static String sample(String values) {
        try { return sampleLocked(values); } finally { drain(); }
    }
    private static String sampleLocked(String values) {
        synchronized (LOCK) {
            if (app == null) return "{\"ok\":false,\"msg\":\"Lanceur pas encore prêt\"}";
            ValueFind.Sample s = new ValueFind.Sample(); s.at = System.currentTimeMillis();
            if (values != null) for (String kv : values.split(";")) {
                int i = kv.indexOf('=');
                if (i <= 0) continue;
                String k = kv.substring(0, i).trim(); Double v = ValueFind.number(kv.substring(i + 1));
                if (v != null && ValueFind.FIELDS.containsKey(k)) s.vals.put(k, v);
            }
            if (s.vals.isEmpty()) return "{\"ok\":false,\"msg\":\"Saisis au moins une valeur\"}";
            s.bytes.putAll(store.snapshot());
            try { for (Map.Entry<String, String> e : CanBridge.propsCopy().entrySet()) addText(s, "P:" + e.getKey(), e.getValue()); } catch (Throwable ignored) {}
            readSettings(s);
            for (Map.Entry<String, String> e : bText.entrySet()) addText(s, e.getKey(), e.getValue());
            samples.add(s);
            while (samples.size() > MAX_SAMPLES) samples.remove(0);
            saveSamples();
            lastResult = ValueFind.analyze(samples);
            List<ValueFind.Rule> l = new ArrayList<>();
            StringBuilder log = new StringBuilder("ORDI APPRIS : relevé n° " + samples.size() + " · saisi " + s.vals + " · " + s.bytes.size() + " messages, " + s.texts.size() + " textes");
            for (ValueFind.Found f : lastResult.values()) {
                if (f.rule != null && f.state >= ValueFind.PROBABLE) l.add(f.rule);
                log.append("\n    ").append(f.field).append(" : ").append(stateName(f.state)).append(f.rule != null ? " · " + f.rule.label() : "").append(" (").append(f.cands).append(" emplacement(s))");
            }
            later(log.toString());
            dump(s);
            apply(l, true);
            return resultJson(true);
        }
    }
    private static void addText(ValueFind.Sample s, String k, String v) {
        if (v == null || s.texts.size() > 1500 || TEXT_NOISE.matcher(k).find() || ValueFind.number(v) == null) return;
        s.texts.put(k, v.trim());
    }
    private static final Uri[] TABLES = { Settings.System.CONTENT_URI, Settings.Global.CONTENT_URI, Settings.Secure.CONTENT_URI };
    private static void readSettings(ValueFind.Sample s) {
        ContentResolver cr = app.getContentResolver();
        for (Uri u : TABLES) {
            Cursor c = null;
            try {
                c = cr.query(u, new String[]{ "name", "value" }, null, null, null);
                if (c == null) continue;
                String t = u.getLastPathSegment();
                while (c.moveToNext()) addText(s, "S:" + t + "/" + c.getString(0), c.getString(1));
            } catch (Throwable ignored) {} finally { if (c != null) c.close(); }
        }
    }
    /** contenu du relevé dans le journal (pour décoder à la main si la recherche ne trouve rien) */
    private static void dump(ValueFind.Sample s) {
        StringBuilder b = new StringBuilder(); int n = 0, lines = 0;
        for (Map.Entry<String, byte[]> e : s.bytes.entrySet()) {
            if (lines >= 160) break;
            b.append(b.length() > 0 ? "\n" : "").append("ORDI relevé ").append(e.getKey()).append(" = x").append(hex(e.getValue()));
            lines++;
            if (++n == 20) { later(b.toString()); b.setLength(0); n = 0; }
        }
        if (b.length() > 0) later(b.toString());
        if (s.bytes.isEmpty()) later("ORDI relevé : aucun message d'octets reçu (" + (Ts10Probe.present() ? "TWUtil muet ou refusé : contact mis ?" : "pas un poste TopWay : seuls propriétés, réglages et diffusions sont cherchés") + ")");
    }
    private static String stateName(int st) { return st == ValueFind.OK ? "trouvé" : st == ValueFind.PROBABLE ? "probable" : st == ValueFind.PENDING ? "à confirmer" : "introuvable"; }

    /** oublie tout : règles et relevés */
    static void clear() {
        synchronized (LOCK) {
            samples.clear(); lastResult = new LinkedHashMap<>();
            apply(new ArrayList<ValueFind.Rule>(), true);
            try { File f = file(); if (f != null && f.exists()) f.delete(); } catch (Throwable ignored) {}
            later("ORDI APPRIS : relevés et règles oubliés");
        }
        drain();
    }
    static boolean has() { return !rules.isEmpty(); }

    /** état pour l'interface (même forme que le résultat d'un relevé) */
    static String status() { synchronized (LOCK) { return resultJson(false); } }

    private static String resultJson(boolean fresh) {
        StringBuilder b = new StringBuilder("{\"ok\":true");
        b.append(",\"fresh\":").append(fresh).append(",\"tw\":").append(Ts10Probe.present()).append(",\"msgs\":").append(store.count).append(",\"keys\":").append(store.keys());
        b.append(",\"samples\":").append(samples.size()).append(",\"learned\":").append(rules.size());
        if (!samples.isEmpty()) {
            ValueFind.Sample s = samples.get(samples.size() - 1);
            b.append(",\"at\":").append(s.at).append(",\"last\":{");
            // dernière valeur saisie pour chaque donnée, tous relevés confondus (préremplit la fiche)
            Map<String, Double> lastVals = new LinkedHashMap<>();
            for (ValueFind.Sample x : samples) lastVals.putAll(x.vals);
            int n = 0; for (Map.Entry<String, Double> e : lastVals.entrySet()) b.append(n++ > 0 ? "," : "").append('"').append(e.getKey()).append("\":").append(ValueFind.num(e.getValue()));
            b.append('}');
        }
        if (lastResult.isEmpty() && !samples.isEmpty()) lastResult = ValueFind.analyze(samples);
        b.append(",\"fields\":[");
        int n = 0;
        for (ValueFind.Found f : lastResult.values()) {
            b.append(n++ > 0 ? "," : "").append("{\"k\":\"").append(f.field).append("\",\"v\":").append(ValueFind.num(f.value)).append(",\"state\":").append(f.state).append(",\"cands\":").append(f.cands);
            if (f.rule != null) b.append(",\"where\":").append(quote(f.rule.label()));
            b.append('}');
        }
        return b.append("]}").toString();
    }
    private static String quote(String s) {
        StringBuilder b = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) { char c = s.charAt(i); if (c == '"' || c == '\\') b.append('\\').append(c); else if (c < 0x20) b.append(' '); else b.append(c); }
        return b.append('"').toString();
    }

    /* =================== relevés gardés sur le poste =================== */
    private static File file() {
        File d = app.getExternalFilesDir(null);
        if (d == null) d = app.getFilesDir();
        return d == null ? null : new File(d, FILE);
    }
    private static String hex(byte[] b) {
        StringBuilder s = new StringBuilder(b.length * 2);
        for (byte x : b) { int v = x & 0xFF; if (v < 16) s.append('0'); s.append(Integer.toHexString(v).toUpperCase(Locale.US)); }
        return s.toString();
    }
    private static byte[] unhex(String h) {
        byte[] b = new byte[h.length() / 2];
        for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(h.substring(i * 2, i * 2 + 2), 16);
        return b;
    }
    /** une ligne par élément, champs séparés par une tabulation : « #S date », « V donnée valeur », « B clé octets », « X clé texte » */
    private static void saveSamples() {
        Writer w = null;
        try {
            File f = file(); if (f == null) return;
            w = new OutputStreamWriter(new FileOutputStream(f, false), "UTF-8");
            for (ValueFind.Sample s : samples) {
                w.write("#S\t" + s.at + "\n");
                for (Map.Entry<String, Double> e : s.vals.entrySet()) w.write("V\t" + e.getKey() + "\t" + e.getValue() + "\n");
                for (Map.Entry<String, byte[]> e : s.bytes.entrySet()) w.write("B\t" + e.getKey() + "\t" + hex(e.getValue()) + "\n");
                for (Map.Entry<String, String> e : s.texts.entrySet()) if (e.getKey().indexOf('\t') < 0 && e.getValue().indexOf('\t') < 0) w.write("X\t" + e.getKey() + "\t" + e.getValue() + "\n");
            }
        } catch (Throwable e) { later("ORDI APPRIS : relevés non enregistrés : " + e); }
        finally { try { if (w != null) w.close(); } catch (Throwable ignored) {} }
    }
    private static void loadSamples() {
        BufferedReader r = null;
        try {
            File f = file();
            if (f == null || !f.exists() || f.length() > 2000000) return;
            r = new BufferedReader(new InputStreamReader(new FileInputStream(f), "UTF-8"));
            ValueFind.Sample s = null; String line;
            while ((line = r.readLine()) != null) {
                String[] p = line.split("\t", 3);
                if (p[0].equals("#S") && p.length >= 2) { s = new ValueFind.Sample(); s.at = Long.parseLong(p[1]); samples.add(s); }
                else if (s == null || p.length < 3) continue;
                else if (p[0].equals("V")) { Double v = ValueFind.number(p[2]); if (v != null && ValueFind.FIELDS.containsKey(p[1])) s.vals.put(p[1], v); }
                else if (p[0].equals("B")) s.bytes.put(p[1], unhex(p[2]));
                else if (p[0].equals("X")) s.texts.put(p[1], p[2]);
            }
            while (samples.size() > MAX_SAMPLES) samples.remove(0);
        } catch (Throwable e) { samples.clear(); later("ORDI APPRIS : relevés illisibles, ignorés : " + e); }
        finally { try { if (r != null) r.close(); } catch (Throwable ignored) {} }
    }

    /** résumé pour le journal exporté : règles en service + contenu des deux derniers relevés */
    static String summary() {
        synchronized (LOCK) {
            StringBuilder b = new StringBuilder("=== Ordinateur de bord appris sans appli ===\n");
            b.append("Messages reçus depuis le démarrage : ").append(store.count).append(" (").append(store.keys()).append(" différents) · relevés : ").append(samples.size()).append('\n');
            for (ValueFind.Rule r : rules) b.append("  ").append(r.field).append(r.conf == ValueFind.OK ? " : " : " (probable) : ").append(r.label()).append('\n');
            if (rules.isEmpty()) b.append("  aucune donnée apprise\n");
            for (int i = Math.max(0, samples.size() - 2); i < samples.size(); i++) {
                ValueFind.Sample s = samples.get(i);
                b.append("Relevé ").append(i + 1).append(" · saisi ").append(s.vals).append('\n');
                for (Map.Entry<String, byte[]> e : s.bytes.entrySet()) b.append("    ").append(e.getKey()).append(" = x").append(hex(e.getValue())).append('\n');
                for (Map.Entry<String, String> e : s.texts.entrySet()) b.append("    ").append(e.getKey()).append(" = ").append(e.getValue()).append('\n');
            }
            return b.append("=== fin ===\n").toString();
        }
    }
}
