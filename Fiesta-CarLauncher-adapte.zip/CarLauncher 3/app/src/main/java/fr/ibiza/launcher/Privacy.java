package fr.ibiza.launcher;

import android.content.Context;
import android.content.pm.ApplicationInfo;

import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * v1.28.3 : le journal que les clients envoient ne doit pas contenir leur vie privée.
 * Relevé dans un journal reçu : notifications WhatsApp (« Message de Papa », numéros de téléphone), nom du téléphone
 * (« iPhone de … ») et adresses Bluetooth.
 *
 * Appliqué à chaque ligne au moment où elle est notée (Hub.log) ET à l'export (fichier, QR codes, rapport) : un journal
 * enregistré par une version plus ancienne est donc nettoyé lui aussi, avec tout ce qui a été appris depuis (nom du
 * téléphone…).
 *
 *  1. Textes des notifications, toasts et fenêtres (lignes TOAST/NOTIF, FENÊTRE, VUE … textes=) :
 *     · applis du poste (système) qui ne sont ni téléphone, ni messagerie, ni contacts, ni Bluetooth, ni CarPlay /
 *       Android Auto : gardés (fenêtre portes, appli CAN, réglages…) ;
 *     · barre système / volet des notifications : seuls les textes qui parlent de la voiture, ou sans lettres (heure), restent ;
 *     · tout le reste (applis installées par le client, messageries, téléphone…) : « [texte masqué] ».
 *  2. Partout : numéros de téléphone, adresses MAC, nom du téléphone (valeurs des propriétés / réglages dont le nom
 *     évoque un nom, un téléphone, une adresse, et appareils Bluetooth appairés), champs texte des diffusions téléphone /
 *     Bluetooth / CarPlay.
 * Le traitement (portes lues dans un message « Porte ouverte »…) reçoit toujours le texte complet : seul le journal est masqué.
 */
final class Privacy {
    private Privacy() {}

    static final int SAFE = 0, SHELL = 1, PRIV = 2;
    static final String MASK = "‹masqué›";

    /** téléphone, messageries, contacts, Bluetooth, projection du téléphone (CarPlay, Android Auto…) */
    static final Pattern COMM = Pattern.compile("phone|dial(?!og)|call(?!back)|telec|teleph|sms|mms|messag|contact|bluetooth|\\.bt|bt\\.|\\bbt_|_bt\\b|whatsapp|telegram|viber|messenger|facebook|instagram|snapchat|tiktok|mail|chat|wechat|carplay|androidauto|android\\.auto|projection|zlink|autokit|autolink|carlink", Pattern.CASE_INSENSITIVE);
    /** v1.28.4 : diffusions téléphone / Bluetooth / projection. Plus strict que COMM (pas « message », « callback », « dialog » :
     *  « …CAN_MESSAGE » est une trame CAN). Leurs champs texte sont masqués, et elles ne donnent ni portes ni ordinateur
     *  de bord (« battery » d'une appli Bluetooth = batterie du téléphone, pas de la voiture). */
    static final Pattern COMM_ACTION = Pattern.compile("phone|dialer|incall|call_?state|calllog|\\bsms|\\bmms|contact|bluetooth|\\.bt[._]|_bt_|\\bbt_|whatsapp|telegram|carplay|androidauto|zlink|autokit|autolink|carlink|a2dp|avrcp|headset|\\bhfp|pbap", Pattern.CASE_INSENSITIVE);
    /** v1.28.4 : clés « …name » techniques, pas personnelles (profil voiture du boîtier CAN, modèle…) : gardées */
    private static final Pattern TECHNAME = Pattern.compile("(car|can|canbus|canbox|vehicle|model|brand|product|platform|board|mcu|soft|firmware|hw|sw|theme|skin|font|layer|tag|log)[._\\-]?(type[._\\-]?)?name", Pattern.CASE_INSENSITIVE);
    private static final Pattern SHELLPKG = Pattern.compile("systemui|systembar|statusbar|navbar|notification", Pattern.CASE_INSENSITIVE);
    private static final Pattern CARAPP = Pattern.compile("can|vehicle|radar|door|obd|canbus|\\bcar\\b|\\.car|car\\.", Pattern.CASE_INSENSITIVE);
    /** textes « voiture » gardés dans la barre système (porte ouverte, radar…) */
    private static final Pattern CARWORD = Pattern.compile("porte|portière|door|coffre|hayon|trunk|boot|tailgate|capot|hood|bonnet|ouvert|open|fermé|closed|radar|recul|reverse|frein|brake|ceinture|belt|carburant|fuel|batterie|battery|huile|oil|révision|vidange|entretien|service|temp|°|km|vitesse|speed|exception|erreur|error|门|开|关|盖|箱|倒车|雷达", Pattern.CASE_INSENSITIVE);
    private static final Pattern LETTER = Pattern.compile("\\p{L}");

    private static final Pattern HEAD = Pattern.compile("^(\\d\\d:\\d\\d:\\d\\d\\.\\d{3}  )?(TOAST/NOTIF|FENÊTRE|VUE|DIFF) (\\S+)(.*)$", Pattern.DOTALL);
    private static final Pattern PHONE_PLUS = Pattern.compile("(?<![\\w+])\\+\\d(?:[ .\\-]?\\d){7,14}(?![\\w])");
    private static final Pattern PHONE_0 = Pattern.compile("(?<![\\w:.\\-+])0\\d(?:[ .\\-]?\\d\\d){4}(?![\\w])");
    private static final Pattern MAC = Pattern.compile("(?<![0-9A-Fa-f:])[0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5}(?![0-9A-Fa-f:])");
    /** propriété / réglage « clé = valeur » dont la clé évoque une donnée personnelle */
    private static final Pattern KEYVAL = Pattern.compile("([\\w.\\-/]*(?:name|phone|addr|imei|meid|iccid|imsi|msisdn|serialno|serial_no|ssid|account|email|android_id|owner)[\\w.\\-]*)(\\s?=\\s?)([^,}\\n]+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern SECRET_KEY = Pattern.compile("name|phone", Pattern.CASE_INSENSITIVE);
    /** champs JSON personnels (diffusions) */
    private static final Pattern JSONKV = Pattern.compile("(\"[^\"]*(?:name|phone|number|numero|contact|caller|addr|address|ssid|email|account)[^\"]*\"\\s*:\\s*)\"((?:[^\"\\\\]|\\\\.)*)\"", Pattern.CASE_INSENSITIVE);
    private static final Pattern JSONSTR = Pattern.compile("(\"[^\"]*\"\\s*:\\s*)\"((?:[^\"\\\\]|\\\\.)*)\"");
    /** états techniques gardés dans les diffusions téléphone / CarPlay */
    private static final Pattern STATEWORD = Pattern.compile("(?i)(state_|status_)?(dis)?connect(ed|ing)?|idle|init\\w*|start\\w*|stop\\w*|play\\w*|pause\\w*|on|off|true|false|ready|error|none|unknown|[0-9.\\-]{1,6}");

    private static final Map<String, Integer> levels = new ConcurrentHashMap<>();
    /** noms à masquer partout (nom du téléphone, appareils Bluetooth appairés) */
    private static final Set<String> secrets = Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());
    private static volatile long btAt = 0;

    /** niveau de confidentialité des textes affichés par une appli */
    static int level(String pkg) {
        if (pkg == null || pkg.isEmpty() || pkg.equals("null")) return PRIV;
        Integer c = levels.get(pkg);
        if (c != null) return c;
        Context ctx = Hub.app;
        int v = compute(pkg, ctx);
        if (ctx != null) levels.put(pkg, v);          // sans contexte, résultat prudent mais pas mémorisé
        return v;
    }
    private static int compute(String pkg, Context ctx) {
        if (ctx != null && pkg.equals(ctx.getPackageName())) return SAFE;
        if (pkg.equals(CanWatchService.HCN)) return SAFE;
        try { String cp = CanApp.pkg(); if (cp != null && !cp.isEmpty() && pkg.equals(cp)) return SAFE; } catch (Throwable ignored) {}
        if (COMM.matcher(pkg).find()) return PRIV;
        if (pkg.equals("android") || SHELLPKG.matcher(pkg).find()) return SHELL;
        if (ctx == null) return PRIV;
        try {
            ApplicationInfo ai = ctx.getPackageManager().getApplicationInfo(pkg, 0);
            if ((ai.flags & (ApplicationInfo.FLAG_SYSTEM | ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0) return SAFE;
            return CARAPP.matcher(pkg).find() ? SAFE : PRIV;     // appli CAN / OBD installée à part
        } catch (Throwable t) { return PRIV; }
    }
    /** les textes de cette appli peuvent-ils servir à deviner les portes ? (pas ceux d'une messagerie) */
    static boolean carText(String pkg) { return level(pkg) != PRIV; }

    /** nettoie un texte du journal (une entrée de plusieurs lignes, ou tout un fichier) */
    static String text(String s) {
        if (s == null || s.isEmpty()) return s;
        loadBt();
        String[] ls = s.split("\n", -1);
        StringBuilder out = new StringBuilder(s.length() + 16);
        int cur = SAFE;                                   // niveau de la dernière ligne VUE (ses lignes « textes= » suivent)
        for (int i = 0; i < ls.length; i++) {
            String l = ls[i];
            try {
                Matcher m = HEAD.matcher(l);
                if (m.find()) {
                    String ts = m.group(1) == null ? "" : m.group(1), kind = m.group(2), pkg = m.group(3), rest = m.group(4);
                    if (kind.equals("DIFF")) l = ts + "DIFF " + pkg + diff(pkg, rest);
                    else {
                        int lv = level(pkg); cur = lv;
                        if (kind.equals("TOAST/NOTIF")) l = ts + kind + " " + pkg + afterDot(rest, 1, lv);
                        else if (kind.equals("FENÊTRE")) l = ts + kind + " " + pkg + afterDot(rest, 2, lv);
                    }
                } else if (l.startsWith("    textes=")) l = "    textes=" + mask(l.substring(11), cur);
                else if (!l.startsWith("    ")) cur = SAFE;
                l = scrub(l);
            } catch (Throwable ignored) { l = scrub(l); }
            out.append(l);
            if (i < ls.length - 1) out.append('\n');
        }
        return out.toString();
    }

    /** « · classe · [textes] » : masque ce qui suit le n-ième « · » */
    private static String afterDot(String rest, int n, int lv) {
        int p = -1;
        for (int k = 0; k < n; k++) { p = rest.indexOf(" · ", p + 1); if (p < 0) return rest; }
        return rest.substring(0, p + 3) + mask(rest.substring(p + 3), lv);
    }
    /** liste de textes « [a, b] » (ou texte simple) selon le niveau de l'appli */
    static String mask(String t, int lv) {
        if (t == null || lv == SAFE) return t;
        String in = t.trim();
        if (in.isEmpty() || in.equals("[]")) return t;
        if (lv == PRIV) return "[texte masqué]";
        boolean br = in.startsWith("[") && in.endsWith("]");
        String body = br ? in.substring(1, in.length() - 1) : in;
        StringBuilder b = new StringBuilder();
        for (String it : body.split(", ")) {
            if (b.length() > 0) b.append(", ");
            b.append(!LETTER.matcher(it).find() || CARWORD.matcher(it).find() ? it : "…");
        }
        return br ? "[" + b + "]" : b.toString();
    }
    /** contenu d'une diffusion : champs personnels masqués ; tous les textes pour les diffusions téléphone / BT / CarPlay */
    private static String diff(String action, String rest) {
        boolean comm = COMM_ACTION.matcher(action).find();
        Matcher m = (comm ? JSONSTR : JSONKV).matcher(rest);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String v = m.group(2);
            boolean keep = v.isEmpty() || STATEWORD.matcher(v).matches()           // « connecting », « disconnected »…
                    || !comm && v.matches("[a-z0-9_.\\-]{1,32}");                  // diffusion voiture : « "name":"door_fl" » technique
            m.appendReplacement(sb, Matcher.quoteReplacement(m.group(1) + "\"" + (keep ? v : MASK) + "\""));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    /** numéros, adresses MAC, noms connus, valeurs personnelles des propriétés et réglages */
    static String scrub(String l) {
        if (l == null || l.isEmpty()) return l;
        Matcher m = KEYVAL.matcher(l);
        if (m.find()) {
            StringBuffer sb = new StringBuffer();
            do {
                String v = m.group(3).trim(), k = m.group(1);
                boolean keep = v.isEmpty() || v.equals(MASK) || v.equals("null")
                        || k.equalsIgnoreCase("name")                                    // « name="ttyS3" » des refus SELinux : un fichier, utile
                        || TECHNAME.matcher(k).find()                                    // can_car_name = profil du boîtier CAN
                        || k.toLowerCase().contains("addr") && v.matches("0x[0-9a-fA-F]{1,4}");   // adresse I2C / registre
                if (keep) { m.appendReplacement(sb, Matcher.quoteReplacement(m.group(0))); continue; }
                if (SECRET_KEY.matcher(m.group(1)).find()) learn(v);
                m.appendReplacement(sb, Matcher.quoteReplacement(m.group(1) + m.group(2) + MASK));
            } while (m.find());
            m.appendTail(sb);
            l = sb.toString();
        }
        for (String s : secrets) if (l.contains(s)) l = l.replace(s, "‹téléphone›");
        l = MAC.matcher(l).replaceAll("‹adresse›");
        l = PHONE_PLUS.matcher(l).replaceAll("‹numéro›");
        l = PHONE_0.matcher(l).replaceAll("‹numéro›");
        return l;
    }
    /** valeur d'une propriété (rapport de compatibilité) */
    static String prop(String key, String v) {
        if (v == null) return null;
        if (KEYVAL.matcher(key + "=x").matches() && !TECHNAME.matcher(key).find()) { learn(v); return MASK; }
        return scrub(v);
    }

    /** retient un nom à masquer partout (« iPhone de … ») */
    static void learn(String v) {
        if (v == null) return;
        v = v.trim();
        if (v.startsWith("\"") && v.endsWith("\"") && v.length() > 1) v = v.substring(1, v.length() - 1).trim();
        int p = v.indexOf(" (avant : ");                  // « PROP k = nouveau (avant : ancien) »
        if (p > 0) { learn(v.substring(p + 10).replaceAll("\\)$", "")); v = v.substring(0, p).trim(); }
        if (v.length() < 4 || v.length() > 64 || !LETTER.matcher(v).find() || v.equals(MASK) || v.equals("null")) return;
        if (MAC.matcher(v).matches() || v.matches("(0x)?[0-9a-fA-F:.\\-]+")) return;      // adresse : masquée par MAC, pas un nom
        if (secrets.size() < 50) secrets.add(v);
    }
    /** noms des appareils Bluetooth appairés (téléphones), relus au plus une fois par minute */
    private static void loadBt() {
        long now = System.currentTimeMillis();
        if (now - btAt < 60000) return;
        btAt = now;
        try {
            android.bluetooth.BluetoothAdapter a = android.bluetooth.BluetoothAdapter.getDefaultAdapter();
            if (a == null) return;
            for (android.bluetooth.BluetoothDevice d : a.getBondedDevices()) learn(d.getName());
        } catch (Throwable ignored) {}               // Android 12+ sans autorisation « appareils à proximité » : rien
    }
}
