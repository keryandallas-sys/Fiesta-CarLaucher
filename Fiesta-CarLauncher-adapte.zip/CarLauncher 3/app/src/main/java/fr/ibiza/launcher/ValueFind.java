package fr.ibiza.launcher;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * v1.29 : « Apprendre l'ordinateur de bord sans appli » — recherche des valeurs.
 *
 * Quand le poste n'a pas d'appli CAN à lire (pas de CarCan, appli sans texte…), les valeurs de l'ordinateur de bord
 * passent quand même dans ce que le poste publie : trames du boîtier CAN (TopWay : TWUtil), diffusions, propriétés,
 * réglages. Le client saisit ce qu'il lit sur son tableau de bord (kilométrage, température extérieure…) ; cette
 * classe cherche ces nombres dans un relevé de toutes les sources, sous les codages habituels des boîtiers
 * (1 à 4 octets, dans les deux sens, échelles ×1, ×0,1, ×0,01, décalage −40 pour les températures…).
 *
 * Un nombre trouvé une seule fois peut être une coïncidence : un deuxième relevé, quand la valeur a changé (après
 * quelques kilomètres), ne garde que les emplacements qui ont suivi. Le kilométrage sert d'ancre : un nombre à 5 ou
 * 6 chiffres sur 3 octets ne se retrouve presque jamais par hasard, et les autres valeurs du même message que lui
 * sont préférées.
 *
 * Rien d'Android ici : la classe se teste sur un ordinateur (tools/test/ValueFindTest.java).
 */
final class ValueFind {
    private ValueFind() {}

    /* ---------- données cherchées ---------- */
    static final class Field {
        final String k; final double tol, relTol, min, max; final int dec; final List<double[]> encs = new ArrayList<>();
        Field(String k, double tol, double relTol, double min, double max, int dec) { this.k = k; this.tol = tol; this.relTol = relTol; this.min = min; this.max = max; this.dec = dec; }
        /** largeur, signé (0/1), échelle, décalage */
        Field e(int w, int sg, double sc, double of) { encs.add(new double[]{ w, sg, sc, of }); return this; }
        double tol(double v) { return Math.max(tol, Math.abs(v) * relTol); }
    }
    static final Map<String, Field> FIELDS = new LinkedHashMap<>();
    private static Field f(String k, double tol, double rel, double min, double max, int dec) { Field x = new Field(k, tol, rel, min, max, dec); FIELDS.put(k, x); return x; }
    static {
        // le kilométrage en premier : les autres valeurs sont cherchées de préférence dans le même message
        f("odo", 1.0, 0, 1, 2000000, 0).e(3, 0, 1, 0).e(4, 0, 1, 0).e(2, 0, 1, 0).e(3, 0, 0.1, 0).e(4, 0, 0.1, 0).e(4, 0, 0.001, 0);
        f("outside", 0.6, 0, -45, 65, 1).e(2, 1, 0.1, 0).e(2, 0, 0.1, -40).e(2, 0, 0.5, -40).e(2, 1, 1, 0).e(1, 0, 0.5, -40).e(1, 0, 1, -40).e(1, 1, 1, 0).e(1, 1, 0.5, 0).e(1, 0, 1, -50);
        f("range", 2.5, 0, 1, 2500, 0).e(2, 0, 1, 0).e(2, 0, 0.1, 0).e(1, 0, 1, 0);
        f("fuel", 1.0, 0, 1, 200, 0).e(2, 0, 0.1, 0).e(2, 0, 0.01, 0).e(2, 0, 1, 0).e(1, 0, 1, 0).e(1, 0, 0.5, 0);
        f("fuel_pct", 2.5, 0, 1, 100, 0).e(1, 0, 1, 0).e(1, 0, 100 / 255.0, 0);
        f("battery", 0.25, 0, 6, 18, 1).e(2, 0, 0.01, 0).e(2, 0, 0.1, 0).e(2, 0, 0.001, 0).e(1, 0, 0.1, 0);
        f("coolant", 2.5, 0, -45, 150, 0).e(2, 1, 0.1, 0).e(2, 0, 0.1, -40).e(1, 0, 1, -40).e(1, 0, 0.5, -40).e(1, 0, 0.75, -48).e(1, 1, 1, 0);
        f("rpm", 100, 0.07, 300, 9000, 0).e(2, 0, 1, 0).e(2, 0, 0.25, 0).e(2, 0, 0.125, 0).e(1, 0, 100, 0).e(1, 0, 50, 0).e(1, 0, 32, 0);
        f("cons", 0.15, 0, 0.5, 60, 1).e(2, 0, 0.1, 0).e(2, 0, 0.01, 0).e(1, 0, 0.1, 0);
        f("avg", 1.2, 0, 1, 250, 0).e(2, 0, 1, 0).e(2, 0, 0.1, 0).e(2, 0, 0.01, 0).e(1, 0, 1, 0);
    }
    /** échelles essayées pour une valeur publiée en texte (propriété, réglage, champ d'une diffusion) */
    private static final double[] TEXT_SC = { 1, 0.1, 0.01, 0.001 };

    /* ---------- règle : où lire une donnée ---------- */
    static final class Rule {
        String field, key; int b0 = -1, off, w; boolean le, sg, text; double sc = 1, of = 0; int conf;
        /** tous les relevés où la règle a été vérifiée */
        transient int hits; transient double score;

        String enc() {
            return field + "|" + key + "|" + b0 + "|" + off + "|" + w + "|" + (le ? 1 : 0) + "|" + (sg ? 1 : 0) + "|" + (text ? 1 : 0) + "|" + sc + "|" + of + "|" + conf;
        }
        static Rule dec(String s) {
            try {
                String[] p = s.split("\\|");
                if (p.length < 11 || !FIELDS.containsKey(p[0])) return null;
                Rule r = new Rule(); r.field = p[0]; r.key = p[1]; r.b0 = Integer.parseInt(p[2]); r.off = Integer.parseInt(p[3]); r.w = Integer.parseInt(p[4]);
                r.le = p[5].equals("1"); r.sg = p[6].equals("1"); r.text = p[7].equals("1"); r.sc = Double.parseDouble(p[8]); r.of = Double.parseDouble(p[9]); r.conf = Integer.parseInt(p[10]);
                if (r.w < 0 || r.w > 4 || r.off < 0 || (!r.text && r.w == 0)) return null;
                return r;
            } catch (Exception e) { return null; }
        }
        /** description lisible, pour le journal et l'écran de résultat */
        String label() {
            if (text) return key + (sc != 1 ? " × " + num(sc) : "");
            return key + (b0 >= 0 ? " (1er octet " + String.format(Locale.US, "%02X", b0) + ")" : "") + ", octet" + (w > 1 ? "s " + off + " à " + (off + w - 1) + (le ? " (inversés)" : "") : " " + off)
                    + (sg ? ", signé" : "") + (sc != 1 ? " × " + num(sc) : "") + (of != 0 ? (of > 0 ? " + " : " − ") + num(Math.abs(of)) : "");
        }
        private boolean sameSpot(Rule o) { return text == o.text && key.equals(o.key) && b0 == o.b0 && (text || (off < o.off + o.w && o.off < off + w)); }
    }
    static String num(double d) { return d == Math.rint(d) ? String.valueOf((long) d) : String.valueOf(Math.round(d * 10000) / 10000.0); }

    /** valeur lue par une règle dans les octets d'un message ; null si absente (octets à FF, message trop court) */
    static Double eval(Rule r, byte[] b) {
        if (b == null || r.text || r.off + r.w > b.length) return null;
        long raw = 0; boolean allFF = true;
        for (int i = 0; i < r.w; i++) {
            int x = b[r.off + (r.le ? r.w - 1 - i : i)] & 0xFF;
            raw = (raw << 8) | x; if (x != 0xFF) allFF = false;
        }
        if (allFF) return null;
        if (r.sg) { long sign = 1L << (r.w * 8 - 1); if ((raw & sign) != 0) raw -= sign << 1; }
        return raw * r.sc + r.of;
    }
    static Double evalText(Rule r, String s) {
        Double d = number(s);
        return d == null ? null : d * r.sc + r.of;
    }
    static Double number(String s) {
        if (s == null) return null;
        s = s.trim().replace(',', '.');
        if (s.length() == 0 || s.length() > 14) return null;
        try { double d = Double.parseDouble(s); return Double.isNaN(d) || Double.isInfinite(d) ? null : d; } catch (Exception e) { return null; }
    }
    /** valeur plausible pour cette donnée, arrondie pour l'affichage ; null si absurde */
    static Double clean(String field, Double v) {
        Field fd = FIELDS.get(field);
        if (fd == null || v == null || v < fd.min || v > fd.max) return null;
        double p = Math.pow(10, fd.dec);
        return Math.round(v * p) / p;
    }

    /* ---------- messages reçus : dernier contenu de chaque message, par variante de premier octet ---------- */
    /** Beaucoup de boîtiers envoient plusieurs « sous-messages » sous le même numéro, distingués par le premier octet
        (ex. profil VW : 0x41 puis 01 / 02 / 03). Jusqu'à 8 premiers octets différents, chacun est gardé à part ;
        au-delà, le premier octet est une donnée qui varie : un seul contenu est gardé. */
    static final class FrameStore {
        private static final int MAX_KEYS = 400, MAX_VAR = 8, MAX_LEN = 64;
        private final Map<String, Map<Integer, byte[]>> vars = new HashMap<>();
        private final Map<String, byte[]> last = new HashMap<>();
        private final Map<String, Boolean> many = new HashMap<>();
        long count = 0;

        static String k1(String base, int len) { return base + "/" + len; }

        synchronized void put(String base, byte[] b) {
            if (b == null || b.length == 0 || b.length > MAX_LEN) return;
            String k = k1(base, b.length);
            if (!last.containsKey(k) && last.size() >= MAX_KEYS) return;
            count++;
            byte[] c = b.clone();
            last.put(k, c);
            if (many.containsKey(k)) return;
            Map<Integer, byte[]> v = vars.get(k);
            if (v == null) vars.put(k, v = new LinkedHashMap<>());
            v.put(c[0] & 0xFF, c);
            if (v.size() > MAX_VAR) { many.put(k, true); vars.remove(k); }
        }
        synchronized int keys() { return last.size(); }
        /** copie pour un relevé : « clé » (premier octet = donnée) ou « clé#premier octet » */
        synchronized Map<String, byte[]> snapshot() {
            Map<String, byte[]> out = new LinkedHashMap<>();
            for (Map.Entry<String, byte[]> e : last.entrySet()) {
                Map<Integer, byte[]> v = vars.get(e.getKey());
                if (v == null) out.put(e.getKey(), e.getValue().clone());
                else for (Map.Entry<Integer, byte[]> x : v.entrySet()) out.put(e.getKey() + "#" + x.getKey(), x.getValue().clone());
            }
            return out;
        }
    }

    /* ---------- relevé : ce que le client a saisi + toutes les sources à cet instant ---------- */
    static final class Sample {
        long at;
        final Map<String, Double> vals = new LinkedHashMap<>();
        final Map<String, byte[]> bytes = new LinkedHashMap<>();
        final Map<String, String> texts = new LinkedHashMap<>();
    }
    private static List<byte[]> bytesFor(Sample s, Rule r) {
        List<byte[]> l = new ArrayList<>();
        if (r.b0 >= 0) {
            byte[] b = s.bytes.get(r.key + "#" + r.b0);
            if (b == null) { b = s.bytes.get(r.key); if (b != null && (b[0] & 0xFF) != r.b0) b = null; }
            if (b != null) l.add(b);
        } else {
            byte[] b = s.bytes.get(r.key);
            if (b != null) l.add(b);
            else { String p = r.key + "#"; for (Map.Entry<String, byte[]> e : s.bytes.entrySet()) if (e.getKey().startsWith(p)) l.add(e.getValue()); }
        }
        return l;
    }
    /** 1 = la règle donne la valeur saisie dans ce relevé, 0 = elle donne autre chose, -1 = source absente du relevé */
    static int check(Rule r, Sample s, double v) {
        Field fd = FIELDS.get(r.field); double tol = fd.tol(v);
        if (r.text) {
            String t = s.texts.get(r.key);
            if (t == null) return -1;
            Double d = evalText(r, t);
            return d != null && Math.abs(d - v) <= tol ? 1 : 0;
        }
        List<byte[]> l = bytesFor(s, r);
        if (l.isEmpty()) return -1;
        for (byte[] b : l) { Double d = eval(r, b); if (d != null && Math.abs(d - v) <= tol) return 1; }
        return 0;
    }

    private static boolean narrower(Field fd, double[] en) {
        for (double[] o : fd.encs) if (o[0] == en[0] - 1 && o[1] == en[1] && o[2] == en[2] && o[3] == en[3]) return true;
        return false;
    }
    /** tous les emplacements d'un relevé qui donnent la valeur v pour cette donnée */
    static List<Rule> candidates(String field, double v, Sample s) {
        List<Rule> out = new ArrayList<>();
        Field fd = FIELDS.get(field);
        if (fd == null) return out;
        double tol = fd.tol(v);
        for (Map.Entry<String, byte[]> e : s.bytes.entrySet()) {
            String key = e.getKey(); int b0 = -1; int h = key.lastIndexOf('#');
            if (h > 0) { try { b0 = Integer.parseInt(key.substring(h + 1)); key = key.substring(0, h); } catch (Exception x) { b0 = -1; key = e.getKey(); } }
            byte[] b = e.getValue();
            for (double[] en : fd.encs) {
                int w = (int) en[0];
                for (int le = 0; le < (w > 1 ? 2 : 1); le++) for (int off = 0; off + w <= b.length; off++) {
                    Rule r = new Rule(); r.field = field; r.key = key; r.off = off; r.w = w; r.le = le == 1; r.sg = en[1] == 1; r.sc = en[2]; r.of = en[3];
                    r.b0 = off == 0 ? -1 : b0;        // la valeur commence au premier octet : il ne peut pas servir de repère
                    long raw = 0; for (int i = 0; i < w; i++) raw = (raw << 8) | (b[off + (r.le ? w - 1 - i : i)] & 0xFF);
                    if (raw == 0 && r.of == 0) continue;                        // un zéro ne prouve rien
                    // octet de poids fort à zéro alors qu'un codage plus court existe : c'est l'octet voisin, pas la valeur
                    // (sauf le kilométrage sur 3 octets, qui dépassera un jour 65 535)
                    if (w > 1 && (b[off + (r.le ? w - 1 : 0)] & 0xFF) == 0 && !(field.equals("odo") && w == 3) && narrower(fd, en)) continue;
                    Double d = eval(r, b);
                    if (d != null && Math.abs(d - v) <= tol) out.add(r);
                }
            }
        }
        for (Map.Entry<String, String> e : s.texts.entrySet()) {
            Double n = number(e.getValue());
            if (n == null || n == 0) continue;
            for (double sc : TEXT_SC) if (Math.abs(n * sc - v) <= tol) {
                Rule r = new Rule(); r.field = field; r.key = e.getKey(); r.text = true; r.sc = sc; out.add(r);
                break;
            }
        }
        return out;
    }

    /* ---------- résultat ---------- */
    static final int OK = 2, PROBABLE = 1, PENDING = 0, NONE = -1;
    static final class Found {
        String field; int state = NONE; Rule rule; int cands; double value;
    }

    /** Analyse tous les relevés : une ligne par donnée saisie au moins une fois. */
    static Map<String, Found> analyze(List<Sample> samples) {
        Map<String, Found> out = new LinkedHashMap<>();
        Rule odo = null;
        for (final Field fd : FIELDS.values()) {
            List<Sample> has = new ArrayList<>();
            for (Sample s : samples) if (s.vals.containsKey(fd.k)) has.add(s);
            if (has.isEmpty()) continue;
            Found fo = new Found(); fo.field = fd.k; out.put(fd.k, fo);
            Sample lastS = has.get(has.size() - 1);
            fo.value = lastS.vals.get(fd.k);
            List<Rule> keep = new ArrayList<>();
            for (Rule r : candidates(fd.k, fo.value, lastS)) {
                boolean ok = true; List<Double> seen = new ArrayList<>(); seen.add(fo.value);
                for (int i = 0; i < has.size() - 1 && ok; i++) {
                    double v = has.get(i).vals.get(fd.k);
                    int c = check(r, has.get(i), v);
                    if (c == 0) ok = false; else if (c == 1) seen.add(v);
                }
                if (!ok) continue;
                r.hits = seen.size();
                // confirmée : vérifiée sur deux relevés où la valeur saisie n'était pas la même
                boolean moved = false;
                for (int i = 0; i < seen.size() && !moved; i++) for (int j = i + 1; j < seen.size(); j++)
                    if (Math.abs(seen.get(i) - seen.get(j)) > 2 * fd.tol(seen.get(i))) { moved = true; break; }
                // sûre dès le premier relevé : grand nombre retrouvé exactement (kilométrage sur 3 ou 4 octets, ou en texte)
                boolean strong = fd.k.equals("odo") && fo.value >= 1000 && (r.text || r.w >= 3);
                r.conf = moved || strong ? OK : PROBABLE;
                r.score = (moved ? 100 : 0) + (strong ? 50 : 0) + (odo != null && !r.text && !odo.text && r.key.equals(odo.key) ? 20 : 0)
                        + (r.text ? 6 : r.w * 2) + (r.sc == 1 ? 1 : 0) + (r.le ? 0 : 0.5) + (r.b0 >= 0 || r.text ? 0.25 : 0);
                keep.add(r);
            }
            Collections.sort(keep, new Comparator<Rule>() { public int compare(Rule a, Rule b) { return Double.compare(b.score, a.score); } });
            // plusieurs codages du même emplacement (3 octets et 4 octets avec un zéro devant…) : un seul gardé, le meilleur
            List<Rule> spots = new ArrayList<>();
            for (Rule r : keep) { boolean dup = false; for (Rule q : spots) if (q.sameSpot(r)) { dup = true; break; } if (!dup) spots.add(r); }
            fo.cands = spots.size();
            if (spots.isEmpty()) continue;
            Rule best = spots.get(0);
            int sameLevel = 0; for (Rule r : spots) if (r.conf == best.conf && Math.floor(r.score / 20) == Math.floor(best.score / 20)) sameLevel++;
            // plusieurs emplacements possibles et aucun confirmé : un autre relevé tranchera (confirmés : le poste publie la
            // même valeur à deux endroits, n'importe lequel convient)
            if (sameLevel > 1 && best.conf != OK) { fo.state = PENDING; continue; }
            fo.state = best.conf; fo.rule = best;
            if (fd.k.equals("odo")) odo = best;
        }
        return out;
    }
}
