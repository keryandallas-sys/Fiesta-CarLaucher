package fr.ibiza.launcher;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

/** Test de ValueFind sur des trames simulées (voir tools/test/README.md). */
public class ValueFindTest {
    static int fails = 0;
    static void ok(boolean c, String what) { System.out.println((c ? "OK   " : "ECHEC ") + what); if (!c) fails++; }

    /** profil VW (Raise / SimpleSoft) : message 0x41, sous-type 2 = régime, vitesse, batterie, extérieur, km, carburant */
    static byte[] vw(int rpm, double batt, double out, int odo, int fuel) {
        int b = (int) Math.round(batt * 100), t = (int) Math.round(out * 10) & 0xFFFF;
        return new byte[]{ 2, (byte) (rpm >> 8), (byte) rpm, 0, 0, (byte) (b >> 8), (byte) b, (byte) (t >> 8), (byte) t, (byte) (odo >> 16), (byte) (odo >> 8), (byte) odo, (byte) fuel };
    }
    static void noise(ValueFind.FrameStore st, Random rnd, int n) {
        for (int i = 0; i < n; i++) {
            byte[] b = new byte[4 + rnd.nextInt(12)]; rnd.nextBytes(b);
            st.put("T:0501/" + (0x20 + rnd.nextInt(12)), b);              // autres messages du boîtier (clim, radars, volant…)
            byte[] c = new byte[6]; rnd.nextBytes(c); st.put("T:9F1C/0", c);   // compteur qui change sans arrêt
        }
    }
    static ValueFind.Sample sample(ValueFind.FrameStore st, Object... kv) {
        ValueFind.Sample s = new ValueFind.Sample(); s.at = System.currentTimeMillis();
        for (int i = 0; i < kv.length; i += 2) s.vals.put((String) kv[i], ((Number) kv[i + 1]).doubleValue());
        s.bytes.putAll(st.snapshot());
        return s;
    }

    public static void main(String[] a) {
        Random rnd = new Random(7);
        // ---- 1. TS10 + boîtier profil VW : deux relevés à 14 km d'écart ----
        ValueFind.FrameStore st = new ValueFind.FrameStore();
        noise(st, rnd, 300);
        st.put("T:0501/65", new byte[]{ 1, 0x40 });                         // sous-type 1 (ceinture, lave-glace)
        st.put("T:0501/65", vw(0, 12.4, 18.5, 123456, 32));
        st.put("T:0501/65", new byte[]{ 3, 0 });
        List<ValueFind.Sample> all = new ArrayList<>();
        all.add(sample(st, "odo", 123456, "outside", 18.5, "fuel", 32, "battery", 12.4));
        Map<String, ValueFind.Found> r = ValueFind.analyze(all);
        ValueFind.Found odo = r.get("odo");
        ok(odo.state == ValueFind.OK && odo.rule.key.equals("T:0501/65/13") && odo.rule.b0 == 2 && odo.rule.off == 9 && odo.rule.w == 3 && !odo.rule.le, "1er relevé : kilométrage trouvé tout de suite (" + (odo.rule == null ? "-" : odo.rule.label()) + ")");
        ok(r.get("outside").state >= ValueFind.PENDING, "1er relevé : température au moins candidate (état " + r.get("outside").state + ", " + r.get("outside").cands + " emplacement(s))");
        noise(st, rnd, 300);
        st.put("T:0501/65", vw(2100, 14.1, 16.0, 123470, 31));
        all.add(sample(st, "odo", 123470, "outside", 16, "fuel", 31, "battery", 14.1, "rpm", 2100));
        r = ValueFind.analyze(all);
        for (String k : new String[]{ "odo", "outside", "battery" }) ok(r.get(k).state == ValueFind.OK && r.get(k).rule.key.equals("T:0501/65/13"), "2e relevé : " + k + " confirmé (" + (r.get(k).rule == null ? "état " + r.get(k).state : r.get(k).rule.label()) + ")");
        ok(r.get("fuel").rule != null && r.get("fuel").rule.off == 12, "2e relevé : carburant à l'octet 12 (état " + r.get("fuel").state + ")");
        ok(r.get("rpm").state == ValueFind.PENDING || r.get("rpm").rule.off == 1, "2e relevé : régime saisi une seule fois, pas de faux « trouvé » (état " + r.get("rpm").state + ", " + r.get("rpm").cands + " emplacement(s))");
        st.put("T:0501/65", vw(850, 14.2, 16.0, 123470, 31));
        all.add(sample(st, "rpm", 850));
        r = ValueFind.analyze(all);
        ok(r.get("rpm").state == ValueFind.OK && r.get("rpm").rule.off == 1, "3e relevé : régime confirmé aux octets 1-2");
        // lecture en direct avec les règles trouvées
        byte[] live = vw(900, 13.9, -3.5, 123501, 29);
        ok(ValueFind.eval(r.get("odo").rule, live) == 123501.0, "direct : kilométrage");
        ok(Math.abs(ValueFind.eval(r.get("outside").rule, live) + 3.5) < 0.01, "direct : température négative");
        ok(Math.abs(ValueFind.eval(r.get("battery").rule, live) - 13.9) < 0.01, "direct : batterie");
        // règle enregistrée puis relue
        ValueFind.Rule back = ValueFind.Rule.dec(r.get("outside").rule.enc());
        ok(back != null && Math.abs(ValueFind.eval(back, live) + 3.5) < 0.01, "règle enregistrée puis relue");

        // ---- 2. autre boîtier : km en 0,1 km sur 4 octets inversés, température octet × 0,5 − 40, sans sous-type ----
        st = new ValueFind.FrameStore(); all = new ArrayList<>();
        noise(st, rnd, 200);
        for (int pass = 0; pass < 2; pass++) {
            int km10 = pass == 0 ? 876543 : 876790; int t = pass == 0 ? 21 : 24;
            for (int i = 0; i < 20; i++) st.put("T:0501/18", new byte[]{ (byte) rnd.nextInt(256), (byte) km10, (byte) (km10 >> 8), (byte) (km10 >> 16), 0, (byte) ((t + 40) * 2), 7 });
            all.add(sample(st, "odo", km10 / 10, "outside", t));
        }
        r = ValueFind.analyze(all);
        ok(r.get("odo").state == ValueFind.OK && r.get("odo").rule.le && r.get("odo").rule.b0 == -1 && r.get("odo").rule.off == 1, "boîtier 2 : km inversés en 0,1 km, premier octet variable (" + (r.get("odo").rule == null ? "-" : r.get("odo").rule.label()) + ")");
        ok(r.get("outside").state == ValueFind.OK && r.get("outside").rule.off == 5, "boîtier 2 : température × 0,5 − 40 (" + (r.get("outside").rule == null ? "état " + r.get("outside").state : r.get("outside").rule.label()) + ")");

        // ---- 3. valeur publiée en texte (propriété / réglage) ----
        all = new ArrayList<>();
        ValueFind.Sample s = new ValueFind.Sample(); s.vals.put("odo", 45210.0); s.vals.put("avg", 47.0);
        s.texts.put("P:persist.sys.car.mileage", "45210"); s.texts.put("S:system/key_can_average_speed", "47"); s.texts.put("P:ro.build.date.utc", "1700000000");
        all.add(s);
        r = ValueFind.analyze(all);
        ok(r.get("odo").state == ValueFind.OK && r.get("odo").rule.text, "texte : kilométrage dans une propriété");
        ok(r.get("avg").state == ValueFind.PROBABLE && r.get("avg").rule.key.endsWith("average_speed"), "texte : vitesse moyenne probable (un seul emplacement)");

        // ---- 4. rien à trouver : le boîtier n'envoie pas la donnée ----
        st = new ValueFind.FrameStore(); noise(st, rnd, 400); all = new ArrayList<>();
        all.add(sample(st, "odo", 187654)); noise(st, rnd, 400); all.add(sample(st, "odo", 187702));
        r = ValueFind.analyze(all);
        ok(r.get("odo").state == ValueFind.NONE, "bruit seul : kilométrage non trouvé (pas de faux positif)");
        // température seule dans du bruit, deux relevés à la même valeur : jamais « confirmé »
        all = new ArrayList<>(); all.add(sample(st, "outside", 18)); all.add(sample(st, "outside", 18));
        r = ValueFind.analyze(all);
        ok(r.get("outside").state != ValueFind.OK, "bruit seul : température jamais confirmée sans changement (état " + r.get("outside").state + ", " + r.get("outside").cands + " emplacement(s))");
        System.out.println(fails == 0 ? "\nTous les tests passent." : "\n" + fails + " test(s) en échec.");
        System.exit(fails == 0 ? 0 : 1);
    }
}
