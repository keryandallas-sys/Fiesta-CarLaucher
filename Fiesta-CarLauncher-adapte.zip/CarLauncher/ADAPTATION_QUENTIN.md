# Adaptation Quentin — Ford Fiesta / TS10

## Paramètres appliqués
- Véhicule : Ford Fiesta 1.6 TDCi, 2010, 5 portes, diesel, blanc.
- Autoradio déclaré : TS10, UIS8581E, Android 15.
- Profil CAN sélectionné : Simple Plan / Ford / 2009 Fiesta / Public.
- Boîtier : HW V02 / SW V107.
- Nom de l’application : Fiesta Car Launcher.

## État CAN — non validé
Le projet d’origine dépend des propriétés `persist.vendor.cem.*` du firmware Junsun/HCN et de CarCan.
Aucun journal du TS10 ni APK CAN CarMate/du décodeur n’a été fourni. Les trames VW de la documentation
ne sont donc PAS réutilisées comme si elles décrivaient le profil Ford. Portes, clignotants, vitesse et ordinateur
de bord restent à diagnostiquer sur l’appareil.

## État 3D — source intégrée, rendu non activé
Le modèle fourni est conservé dans `tools/render/model/fiesta_blanc_source.glb`. Il contient 25 maillages
nommés (dont `Mesh7_vidrios_0`, `Mesh13_disk_0`, `Mesh16_FIESTA_rin_0`, etc.). Les noms ne suffisent pas
à prouver que les quatre portes sont des pièces séparées et animables. Le pipeline `build2.py` d’origine
attend un FBX Ibiza et des textures spécifiques ; aucun rendu n’a été généré ni déclaré validé.
`carPack` et `topView` restent donc à `false` pour éviter d’afficher des images inexistantes.

## Contrôles
- `config.js` modifié pour le véhicule.
- `strings.xml` modifié pour le nom affiché.
- JavaScript : à vérifier avec Node.js (`node --check`) sur les fichiers JS.
- Java/Gradle : compilation complète non exécutée dans cet environnement (Android SDK/Gradle wrapper à confirmer).
