package fr.ibiza.launcher;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

/**
 * v1.22.1 : sondage du CAN sur les autoradios TopWay (TS10 / TS18, firmware « tw », appli système com.tw.service).
 *
 * Sur ces postes, il n'y a ni CarCan ni propriétés persist.vendor.cem.* : les trames du boîtier CAN arrivent du
 * microcontrôleur par la classe système android.tw.john.TWUtil (message 0x0501 = trame CAN : arg1 = commande du
 * protocole du boîtier, obj = octets). com.tw.service et com.tw.service.xt l'ouvrent chacun de leur côté, avec les mêmes
 * numéros : plusieurs lecteurs sont donc prévus.
 *
 * Ce sondage est un outil de diagnostic, lancé à la main depuis les réglages, pour une durée limitée :
 *  - lecture seule (aucune écriture vers le microcontrôleur) ;
 *  - chaque message n'est noté dans le journal que quand son contenu change, avec un plafond, pour ne pas le noyer ;
 *  - un résumé (nombre de messages par type) est noté à la fin.
 * Les trames notées servent ensuite à décoder portes, coffre, vitesse, température, carburant… pour le boîtier du client.
 * Sur un poste qui n'est pas un TopWay, la classe n'existe pas : rien n'est fait.
 */
final class Ts10Probe {
    private Ts10Probe() {}

    private static final String CLS = "android.tw.john.TWUtil";
    private static final String NAME = "CarLauncher";
    // numéros ouverts par com.tw.service (sauf touches et volume) : version MCU, état système, CAN, marche arrière…
    private static final short[] IDS = { 266, 267, 769, 770, 773, 774, 1028, 1281, 1285, 1287, 1288, 1289, 1294,
            (short) 0x9E00, (short) 0x9E11, (short) 0x9F10, (short) 0x9F1B, (short) 0x9F1C };
    private static final int MAX_LINES = 350, MAX_PER_KEY = 25;

    private static Boolean present;
    private static volatile boolean running;
    private static Object tw;
    private static Class<?> cls;
    private static HandlerThread thread;
    private static final Map<String, String> last = new HashMap<>();
    private static final Map<String, Integer> count = new TreeMap<>(), logged = new HashMap<>();
    private static int lines;
    private static final Object LOCK = new Object();   // compteurs (le fil de TWUtil n'attend jamais le verrou de la classe)

    /** vrai sur un TopWay (classe TWUtil présente dans le système) */
    static synchronized boolean present() {
        if (present == null) {
            try { Class.forName(CLS); present = true; } catch (Throwable t) { present = false; }
        }
        return present;
    }

    static boolean running() { return running; }

    /** noté une fois au démarrage du lanceur, pour savoir tout de suite sur quel type de poste on est */
    private static boolean platformLogged;
    static synchronized void logPlatform() {
        if (platformLogged) return;
        platformLogged = true;
        if (present()) Hub.log("Plateforme : TopWay (TWUtil présent). Portes lues dans la fenêtre portes de com.tw.service ; "
                + "sondage du CAN possible dans Réglages > Données CAN du poste");
    }

    /** lance le sondage pour « seconds » secondes ; renvoie un message court pour l'interface */
    static synchronized String start(int seconds) {
        if (!present()) return "Ce poste n'est pas un TopWay (TS10 / TS18) : rien à sonder";
        if (running) return "Sondage déjà en cours";
        try {
            cls = Class.forName(CLS);
            Object o;
            try { o = cls.getConstructor().newInstance(); }
            catch (Throwable e) { o = cls.getConstructor(int.class).newInstance(16); }
            Object r = cls.getMethod("open", short[].class).invoke(o, (Object) IDS);
            if (r instanceof Integer && (Integer) r != 0) {
                Hub.log("TS10 : ouverture de TWUtil refusée (code " + r + ")");
                return "Ouverture refusée par le poste (code " + r + ")";
            }
            tw = o;
            cls.getMethod("start").invoke(o);
            thread = new HandlerThread("ibiza-ts10"); thread.start();
            Handler h = new Handler(thread.getLooper()) {
                @Override public void handleMessage(Message m) { onMessage(m); }
            };
            synchronized (LOCK) { last.clear(); count.clear(); logged.clear(); lines = 0; }
            tw = o; running = true;
            cls.getMethod("addHandler", String.class, Handler.class).invoke(o, NAME, h);
            Hub.log("TS10 : sondage du CAN démarré pour " + seconds + " s (lecture seule)");
            h.postDelayed(new Runnable() { public void run() { stop(); } }, seconds * 1000L);
            return "Sondage lancé pour " + Math.max(1, seconds / 60) + " min";
        } catch (Throwable e) {
            Throwable t = e instanceof InvocationTargetException ? ((InvocationTargetException) e).getTargetException() : e;
            Hub.log("TS10 : TWUtil inaccessible pour le lanceur : " + t);
            running = false;
            release();
            return "TWUtil inaccessible (" + t.getClass().getSimpleName() + ")";
        }
    }

    static synchronized void stop() {
        if (!running) return;
        running = false;
        StringBuilder sb = new StringBuilder();
        synchronized (LOCK) {
            for (Map.Entry<String, Integer> e : count.entrySet()) sb.append(e.getKey()).append(" ×").append(e.getValue()).append(", ");
        }
        Hub.log(sb.length() == 0 ? "TS10 : fin du sondage, aucun message reçu (TWUtil ouvert mais muet)"
                : "TS10 : fin du sondage. Messages reçus : " + sb.substring(0, sb.length() - 2));
        release();
    }

    private static void release() {
        try { if (tw != null) cls.getMethod("removeHandler", String.class).invoke(tw, NAME); } catch (Throwable ignored) {}
        try { if (tw != null) cls.getMethod("stop").invoke(tw); } catch (Throwable ignored) {}
        try { if (tw != null) cls.getMethod("close").invoke(tw); } catch (Throwable ignored) {}
        tw = null;
        if (thread != null) { thread.quitSafely(); thread = null; }
    }

    private static void onMessage(Message m) {
        if (!running) return;
        int what = m.what & 0xFFFF;
        String key = String.format(Locale.US, "0x%04X/%d", what, m.arg1);
        String data = format(m.obj);
        String sig = m.arg2 + "|" + data;
        String line = null;
        synchronized (LOCK) {
            Integer c = count.get(key); count.put(key, c == null ? 1 : c + 1);
            if (sig.equals(last.get(key))) return;                 // contenu identique : déjà noté
            last.put(key, sig);
            Integer k = logged.get(key); int nk = k == null ? 1 : k + 1; logged.put(key, nk);
            if (nk > MAX_PER_KEY || lines >= MAX_LINES) return;    // message qui change sans cesse (vitesse, régime…)
            lines++;
            line = String.format(Locale.US, "TS10 0x%04X a1=%d (0x%02X) a2=%d %s%s", what, m.arg1, m.arg1 & 0xFF, m.arg2, data,
                    nk == MAX_PER_KEY ? " (dernière notée pour ce message)" : "");
        }
        Hub.log(line);
    }

    private static String format(Object o) {
        if (o == null) return "-";
        if (o instanceof byte[]) {
            byte[] b = (byte[]) o;
            StringBuilder sb = new StringBuilder("[").append(b.length).append("] ");
            for (int i = 0; i < b.length && i < 48; i++) sb.append(String.format(Locale.US, "%02X ", b[i] & 0xFF));
            if (b.length > 48) sb.append("…");
            return sb.toString().trim();
        }
        if (o instanceof String) return "\"" + o + "\"";
        return o.getClass().getSimpleName() + " " + o;
    }
}
