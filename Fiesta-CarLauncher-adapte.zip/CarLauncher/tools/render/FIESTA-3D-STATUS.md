# Préparation du pack 3D Ford Fiesta

Le modèle source `model/fiesta_blanc_v2.glb` est inclus dans cette archive.

## État
- Configuration véhicule : Ford Fiesta 1.6 TDCi 2010, 5 portes, diesel.
- Modèle GLB source : intégré au dossier `tools/render/model/`.
- Pack d'images `img/car/hero_00.webp` à `hero_47.webp` : pas encore généré.
- `carPack` reste volontairement `false` : l'activer sans les 48 images ferait apparaître un emplacement vide.
- Ouverture des portes : hors périmètre de cette première version.

## Pourquoi le rendu n'est pas activé
Le launcher dessine la voiture dans un canvas à partir de 48 images WebP pré-rendues. Il ne charge pas directement un fichier GLB. Le modèle source est donc conservé dans le projet, mais il faut encore produire et contrôler les rendus Blender avant activation.

## Étape suivante
Rendre 48 vues de contrôle depuis le GLB, vérifier l'orientation, le cadrage, les matériaux (carrosserie blanche, vitrages et jantes noirs), puis seulement après validation copier les WebP dans `app/src/main/assets/www/img/car/` et activer `carPack`.
